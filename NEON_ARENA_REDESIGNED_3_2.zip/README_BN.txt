NEON ARENA 3.2 — REDESIGNED ANDROID PROJECT

Features:
- Redesigned dark futuristic neon dashboard
- Tic Tac Toe: Easy, Medium and Unbeatable AI; local 2-player
- Local player profile and generated player ID
- Local wins, losses, draws, streak and best streak
- Achievements, theme toggle, sound and vibration controls
- Local device save using browser storage

Important:
- This build does NOT include real online accounts, cloud sync, friends,
  global leaderboard or online multiplayer.
- Those require a configured and tested backend.
- App ID remains com.neonarena.game so it can update the previous app.
- Build with Java 17 and Android Gradle Plugin 8.7.3.
