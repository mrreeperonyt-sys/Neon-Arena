NEON ARENA 3.0
Android WebView project. Build with JDK 17 and Gradle 8.9.

Included:
- Offline Tic Tac Toe
- VS AI (Easy / Medium / Unbeatable) and local 2-player
- Device-local profile name and statistics
- English game interface

Important:
- Cloud account, friends, global leaderboard and cross-device sync are NOT enabled in this build.
- The project does not claim Firebase authentication is working. These features need a properly configured backend and security rules.
- Package: com.neonarena.game
- Version: 3.0 (versionCode 3)
