NEON ARENA — Android APK Project
=================================

এই ZIP-এ NEON ARENA Tic Tac Toe গেমটি Android অ্যাপের ভিতরে অফলাইনে চালানোর জন্য প্রস্তুত Android project আছে।

গুরুত্বপূর্ণ:
- এটি APK ফাইল নয়; এটি APK build করার সম্পূর্ণ source project।
- এই পরিবেশে Android SDK/Gradle build tools নেই, তাই এখানে সরাসরি APK compile করে দেওয়া সম্ভব হয়নি।
- APK build হলে GitHub Actions থেকে app-debug.apk পাওয়া যাবে।
- গেমের HTML, profile, score এবং progress ডিভাইসের WebView storage-এ থাকবে।
- অ্যাপটি portrait ও fullscreen mode-এ চলবে।

ফোন দিয়ে APK বানানোর উপায় (GitHub Actions):
1. ZIP-টি Extract করো।
2. GitHub-এ নতুন repository তৈরি করো, নাম দাও NeonArena।
3. Extract করা project-এর ভেতরের সব ফাইল ও folder repository-তে upload করো। .github folder-টিও upload করতে হবে।
4. Upload শেষ হলে repository-র Actions tab খোলো।
5. "Build NEON ARENA APK" workflow নির্বাচন করে "Run workflow" চাপো।
6. Build শেষ হলে সফল workflow run খুলে নিচের Artifacts থেকে "NEON-ARENA-APK" download করো।
7. ZIP extract করলে app-debug.apk পাবে। সেটি Android-এ install করো।

নিরাপত্তা:
- APK install করার আগে কেবল নিজের তৈরি project-এর build-ই ব্যবহার করো।
- GitHub Actions build-এর জন্য Java 17, Gradle 8.9 এবং Android SDK ব্যবহার করা হয়েছে।
